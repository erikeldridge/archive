<?php
$credentials = array(
    'asd456' => array('foo', 'bar'),
    'qwe123' => array('baz', 'bark'),
);
return $credentials;
?>