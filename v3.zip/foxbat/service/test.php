<?php
//no hash => error
$url = 'http://localhost/~eldridge/foxbat/service/';
$ch = curl_init($url.'?hash=asd456');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$resp = curl_exec($ch);
$dom = new DOMDocument();
@$dom->loadHTML($resp);
$elements = $dom->getElementsByTagName('iframe');
assert(7 == $elements->length);
var_dump($resp);

?>