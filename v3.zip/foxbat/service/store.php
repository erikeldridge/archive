<?php
return array(
    //hash => services => {service1 => {name, url, auth type, key (opt), secret (opt)}, service2 => ...}
    'asd456' => array(
        'privateco' => array(
            'key'=>'qwe', 
            'secret'=>'123', 
            'token'=>''
        )
    ),
    'qwe123' => array('baz', 'bark'),
);
?>